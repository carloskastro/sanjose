# triqui-PHP
un triqui realizado en php
